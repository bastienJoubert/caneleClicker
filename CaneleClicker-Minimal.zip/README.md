# Clicker
> Simple repository to make a simple clicker game and teach HTML, CSS and Javascript.


[Live demo](https://tym17.github.io/CanneleClicker/)


### Credits
**Caneles_stemilion.jpg** by Robyn Lee *(CC BY-SA 2.5)*

**canele-vec.png** by Tym17 *(CC BY-SA)*
